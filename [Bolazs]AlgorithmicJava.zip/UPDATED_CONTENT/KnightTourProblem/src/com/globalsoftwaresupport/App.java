package com.globalsoftwaresupport;

public class App {

	public static void main(String[] args) {
		
		KnightTour problem = new KnightTour(50);
		problem.solve();
	}
}
