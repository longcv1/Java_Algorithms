package com.globalsoftwaresupport;

public class App {

	public static void main(String[] args) {
		
		SumAlgorithm algorithm = new SumAlgorithm();
		System.out.println(algorithm.iteration(100));
		System.out.println(algorithm.recursion(100));
	}
}
