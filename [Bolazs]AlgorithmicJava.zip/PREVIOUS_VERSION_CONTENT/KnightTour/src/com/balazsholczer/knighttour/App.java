package com.balazsholczer.knighttour;

public class App {

	public static void main(String[] args) {
		
		KnightTour knightTour = new KnightTour();
		knightTour.solveKnightTourProblem();
		
	}
}
