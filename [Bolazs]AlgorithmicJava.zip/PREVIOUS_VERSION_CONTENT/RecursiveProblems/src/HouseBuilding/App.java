package HouseBuilding;

public class App {

	public static void main(String[] args) {
		
		Algorithm algorithm = new Algorithm();
		algorithm.buildLayers(4);
		
	}
}
